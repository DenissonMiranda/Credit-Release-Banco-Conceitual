----------------------------------------INSERT---------------------------
Use DbCreditRelease;

--------------------------------------------------------CLIENTE
INSERT INTO [DbCreditRelease].[dbo].[CLIENTE] (CPF, NOME, Uf, Celular)
VALUES ('12345689000', 'Denisson', 'BA', '71988222222'),
	   ('98765432100', 'Maria Oliveira', 'RJ', '2199999999'),
	   ('12345678901', 'Maria Silva', 'SP', '11987654321'),
	   ('23456789012', 'Jo�o Santos', 'SP', '11976543210'),
	   ('34567890123', 'Luciana Souza', 'SP', '11965432109'),
	   ('45678901234', 'Pedro Castro', 'SP', '11954321098'),
	   ('56789012345', 'Fernanda Oliveira', 'SP', '11943210987');,
	   ('67890123456', 'Marcos Santos', 'SP', '11932109876'),
	   ('78901234567', 'Carla Rodrigues', 'SP', '11921098765'),
	   ('89012345678', 'Rafael Lima', 'SP', '11910987654'),
	   ('90123456789', 'Camila Costa', 'SP', '11809876543'),
	   ('01234567890', 'Thiago Oliveira', 'SP', '11798765432');

------------------------------------------------------- FINANCIAMENTO ------------------------------------------
INSERT INTO [DbCreditRelease].[dbo].[FINANCIAMENTO] (TIPO, VALOR_TOTAL, DATA_ULTIMO_VENCIMENTO, CPF)
VALUES
('Empr�stimo Pessoal', 5000.00, '2023-04-30', '01234567890'),
('Cart�o de Cr�dito', 2000.00, '2023-04-30', '01234567890'),
('Financiamento Imobili�rio', 200000.00, '2030-04-30', '12345678901'),
('Financiamento de Ve�culo', 40000.00, '2025-04-30', '12345678901'),
('Empr�stimo Pessoal', 3000.00, '2023-04-30', '12345689000'),
('Cart�o de Cr�dito', 1500.00, '2023-04-30', '12345689000'),
('Financiamento Imobili�rio', 250000.00, '2030-04-30', '23456789012'),
('Financiamento de Ve�culo', 30000.00, '2025-04-30', '23456789012'),
('Empr�stimo Pessoal', 4000.00, '2023-04-30', '34567890123'),
('Cart�o de Cr�dito', 1000.00, '2023-04-30', '34567890123'),
('Financiamento Imobili�rio', 180000.00, '2030-04-30', '45678901234'),
('Financiamento de Ve�culo', 20000.00, '2025-04-30', '45678901234'),
('Empr�stimo Pessoal', 6000.00, '2023-04-30', '56789012345'),
('Cart�o de Cr�dito', 3000.00, '2023-04-30', '56789012345'),
('Financiamento Imobili�rio', 300000.00, '2030-04-30', '67890123456'),
('Financiamento de Ve�culo', 35000.00, '2025-04-30', '67890123456'),
('Empr�stimo Pessoal', 7000.00, '2023-04-30', '78901234567'),
('Cart�o de Cr�dito', 4000.00, '2023-04-30', '78901234567'),
('Financiamento Imobili�rio', 400000.00, '2030-04-30', '89012345678'),
('Financiamento de Ve�culo', 45000.00, '2025-04-30', '89012345678'),
('Empr�stimo Pessoal', 8000.00, '2023-04-30', '90123456789'),
('Cart�o de Cr�dito', 5000.00, '2023-04-30', '90123456789'),
('Financiamento Imobili�rio', 500000.00, '2030-04-30', '98765432100'),
('Financiamento de Ve�culo', 50000.00, '2025-04-11', '98765432100');

------------------------------------------------------- PARCELA ------------------------------------------
INSERT INTO [DbCreditRelease].[dbo].[PARCELA] (NUMERO, VALOR, DATA_VENCIMENTO, DATA_PAGAMENTO, ID_FINANCIAMENTO)
VALUES (1, 500.00, '2022-11-30', '2022-11-30', 10),
       (2, 3000.00, '2022-12-31', '2022-12-31', 10),
       (3, 200.00, '2023-01-31', '2023-01-31', 10),
       (4, 200.00, '2023-02-28', '2023-02-28', 10),
       (5, 250.00, '2023-03-31', NULL, 10),
       (1, 100.00, '2022-11-30', '2022-11-30', 11),
       (2, 100.00, '2022-12-31', '2022-12-31', 11),
       (3, 500.00, '2023-01-31', '2023-01-31', 11),
       (4, 500.00, '2023-02-28', '2023-02-28', 11),
       (5, 1000.00, '2023-03-31', NULL, 11),
       (1, 50000.00, '2022-11-30', '2022-11-30', 12),
       (2, 50000.00, '2022-12-31', '2022-12-31', 12),
       (3, 50000.00, '2023-01-31', '2023-01-31', 12),
       (4, 1000.00, '2023-02-28', '2023-02-28', 12),
       (6, 49000.00, '2023-03-31', NULL, 12),
       (1, 1000.00, '2022-11-30', '2022-11-30', 14),
       (2, 500.00, '2022-12-31', '2022-12-31', 14),
       (3, 100.00, '2023-01-31', '2023-01-31', 14),
       (4, 200.00, '2023-02-28', '2023-02-28', 14),
       (5, 1200.00, '2023-03-31', NULL, 14),
       (1, 150.00, '2022-11-30', '2022-11-30', 15),
       (2, 150.00, '2022-12-31', '2022-12-31', 15),
       (3, 500.00, '2023-01-31', '2023-01-31', 15),
       (4, 200.00, '2023-02-28', '2023-02-28', 15),
       (5, 500.00, '2023-03-31', NULL, 15);

-------------------------------------------------
INSERT INTO [DbCreditRelease].[dbo].[PARCELA] (NUMERO, VALOR, DATA_VENCIMENTO, DATA_PAGAMENTO, ID_FINANCIAMENTO)
SELECT ROW_NUMBER() OVER (ORDER BY ID_FINANCIAMENTO ASC) AS NUMERO,
       CASE WHEN ID_FINANCIAMENTO BETWEEN 25 AND 30 THEN 
		    VALOR_TOTAL / 5
       ELSE  
	        VALOR_TOTAL
       END AS VALOR,
      CASE WHEN ID_FINANCIAMENTO BETWEEN 25 AND 30 THEN 
	      DATEADD(DAY, (ROW_NUMBER() OVER (ORDER BY ID_FINANCIAMENTO ASC) - 1) * 30, GETDATE())
      ELSE 
	      DATA_ULTIMO_VENCIMENTO
	  END AS DATA_VENCIMENTO,
	  NULL AS DATA_PAGAMENTO,
	  ID_FINANCIAMENTO
 FROM [DbCreditRelease].[dbo].[FINANCIAMENTO]
WHERE (ID_FINANCIAMENTO BETWEEN 25 AND 30 
       AND DATEDIFF(DAY, DATA_ULTIMO_VENCIMENTO, GETDATE()) > 5)
        OR (ID_FINANCIAMENTO NOT BETWEEN 25 AND 30);

--Explica��o:

--A fun��o ROW_NUMBER() � utilizada para gerar um n�mero sequencial para as parcelas, ordenadas pelo ID_FINANCIAMENTO.
-- A primeira CASE � utilizada para calcular o valor das parcelas. Para os financiamentos de ID 25 a 30, o valor � dividido em 5 parcelas iguais. 
	--Para os demais financiamentos, o valor total � considerado para cada parcela, padr�o de valores apenas ilustrativos que usei como base para poder gerar a query.

--A segunda  CASE � utilizada tamb�m para calcular a data de vencimento das parcelas. 
  --Para os financiamentos de ID 25 a 30, as parcelas vencem a cada 30 dias a partir da data atual. Para os demais financiamentos, a data de vencimento � a DATA_ULTIMO_VENCIMENTO do financiamento.

--A WHERE � utilizada para filtrar os financiamentos que atendem �s regras de clientes que possuem alguma parcela com mais de cinco dias em atraso.

