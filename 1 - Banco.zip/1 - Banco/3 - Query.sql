
------------------------------------------------------------------------------------ QUERY -------------------------------------------------------------------
select * from CLIENTE;

SELECT * FROM FINANCIAMENTO;

SELECT * FROM PARCELA;


--- Listar todos os clientes do estado de SP que possuem mais de 60% das parcelas pagas
SELECT DISTINCT c.CPF, 
	   c.NOME, 
	   c.UF
  FROM CLIENTE c, 
	   FINANCIAMENTO f, 
	   (SELECT * 
		  FROM PARCELA PA
         WHERE PA.DATA_PAGAMENTO IS NOT NULL) p
 WHERE c.UF = 'SP'
   AND c.CPF = f.CPF
   AND f.ID_FINANCIAMENTO = p.ID_FINANCIAMENTO
 GROUP BY c.CPF, 
		  c.NOME, 
		  c.UF,
		  F.VALOR_TOTAL
HAVING SUM(p.valor) >= (F.VALOR_TOTAL * 0.6);

-- Lista r os p rimeiros quatro clientes que possuem alguma parcela com mais de cinco dias em atraso (Data Vencimento maior que da ta atual E data pagamento nula)

SELECT DISTINCT c.CPF, 
	   c.NOME, 
	   c.UF
  FROM CLIENTE c, 
	   FINANCIAMENTO f, 
	   PARCELA p
 WHERE c.UF = 'SP'
   AND c.CPF = f.CPF
   AND f.ID_FINANCIAMENTO = p.ID_FINANCIAMENTO
   AND p.DATA_VENCIMENTO > GETDATE()
 GROUP BY c.CPF, 
		  c.NOME, 
		  c.UF,
		  p.DATA_VENCIMENTO;

		   